package com.example.nmsmobile

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private const val PREFS = "nms_feedback"
private const val KEY_RATING = "rating"
private const val KEY_COMMENT = "comment"

@Composable
fun FeedbackScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    var rating by remember { mutableStateOf(prefs.getInt(KEY_RATING, 0)) }
    var comment by remember { mutableStateOf(prefs.getString(KEY_COMMENT, "") ?: "") }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(top = 16.dp),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Ratings & Reviews", style = MaterialTheme.typography.titleLarge)
                Text("Rate your experience using the app.", style = MaterialTheme.typography.bodyMedium)

                RatingRow(
                    rating = rating,
                    onRatingChange = { rating = it }
                )

                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Optional comment") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )

                Button(
                    onClick = {
                        prefs.edit()
                            .putInt(KEY_RATING, rating)
                            .putString(KEY_COMMENT, comment)
                            .apply()

                        Toast.makeText(context, "Thanks! Feedback saved.", Toast.LENGTH_SHORT).show()
                    },
                    enabled = rating in 1..5,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Submit Feedback") }

                if (prefs.getInt(KEY_RATING, 0) != 0) {
                    Divider()
                    Text("Last saved:", style = MaterialTheme.typography.titleSmall)
                    Text("Rating: ${prefs.getInt(KEY_RATING, 0)}/5")
                    val last = prefs.getString(KEY_COMMENT, "") ?: ""
                    if (last.isNotBlank()) Text("Comment: $last")
                }
            }
        }
    }
}

@Composable
private fun RatingRow(rating: Int, onRatingChange: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        (1..5).forEach { i ->
            FilterChip(
                selected = rating == i,
                onClick = { onRatingChange(i) },
                label = { Text("$i") }
            )
        }
    }
}
