# Data transfer objects placeholder
